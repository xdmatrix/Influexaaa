import ConnectForm from "@/components/ConnectForm";

export const metadata = {
  title: "Let's Connect",
  description: "Start a conversation with Influexa. Tell us who you are and what you're building — we reply to every serious inquiry within two business days.",
  alternates: { canonical: "/connect" },
};

export default function ConnectPage() {
  return (
    <section className="page-hero" style={{ paddingBottom: "120px" }}>
      <div className="page-hero__inner" style={{ maxWidth: "620px" }}>
        <span className="page-hero__eyebrow">Let's Connect</span>
        <h1 className="page-hero__title gradtext" style={{ fontSize: "clamp(44px,7vw,84px)" }}>Start A<br />Conversation.</h1>
        <p className="page-hero__sub" style={{ marginBottom: "40px" }}>Tell us who you are and what you're building. We reply to every serious inquiry within two business days.</p>
        <div style={{ background: "var(--glass)", border: "1px solid var(--line-2)", borderRadius: "18px", padding: "40px", boxShadow: "var(--shadow-md), var(--bevel)" }}>
          <ConnectForm />
        </div>
      </div>
    </section>
  );
}
