import Image from "next/image";
import { SectionHead, Tiles } from "@/components/Blocks";
import TalentGrid from "@/components/TalentGrid";
import CTA from "@/components/CTA";
import { talents } from "@/data/talents";
import { talentProvides, talentManagement } from "@/data/services";

export const metadata = {
  title: "Talent",
  description: "Influexa represents gaming creators who don't just reach audiences — they hold them. Meet the roster and our talent management philosophy.",
  alternates: { canonical: "/talent" },
};

export default function TalentPage() {
  return (
    <>
      <section className="page-hero">
        <div className="page-hero__inner">
          <span className="page-hero__eyebrow">Talent Management</span>
          <h1 className="page-hero__title gradtext">The People<br />Behind <em>The Play.</em></h1>
          <p className="page-hero__sub">We represent gaming creators who don't just reach audiences — they hold them. This is the roster, and the philosophy behind how we grow it.</p>
        </div>
      </section>

      <section className="section">
        <div className="shell">
          <div className="split">
            <div className="split__body reveal is-visible">
              <p className="eyebrow">Who Are Our Talents?</p>
              <h2 className="title gradtext">Creators With<br />Real Communities.</h2>
              <p>Our talents are streamers, competitors, hardware obsessives and culture commentators — the people gaming audiences actually trust. Each one owns a distinct corner of the space, from ranked FPS grinds to narrative RPG storytelling.</p>
              <p>We don't sign reach for the sake of reach. We sign voices: creators whose audiences show up, stay, and act. That trust is the asset every brand partnership is built on.</p>
            </div>
            <div className="split__media reveal is-visible d1">
              <Image src="https://images.unsplash.com/photo-1542751371-adc38448a05e?w=900&q=80&auto=format&fit=crop" alt="Gaming creator at work" fill sizes="(max-width:1024px) 100vw, 50vw" />
            </div>
          </div>
        </div>
      </section>

      <section className="section section--alt glow">
        <div className="shell">
          <SectionHead eyebrow="Why & How We Manage Talent" title="A Long-Term<br>Partnership." />
          <Tiles items={talentManagement} />
        </div>
      </section>

      <section className="section glow">
        <div className="shell">
          <SectionHead eyebrow="The Roster" title="Some Of<br>Our Talents." />
          <TalentGrid talents={talents} />
        </div>
      </section>

      <section className="section section--alt">
        <div className="shell">
          <SectionHead eyebrow="For Our Creators" title="What We<br>Provide." />
          <Tiles items={talentProvides} />
        </div>
      </section>

      <CTA eyebrow="How You Can Join Us" title="Think You Belong<br>On This Roster?" sub="We're selective, but always looking. If you're a gaming creator serious about your career, we want to hear from you." button="Apply To Join" />
    </>
  );
}
