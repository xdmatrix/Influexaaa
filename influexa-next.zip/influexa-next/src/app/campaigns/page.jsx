import Image from "next/image";
import { SectionHead, Tiles } from "@/components/Blocks";
import CampaignGrid from "@/components/CampaignGrid";
import CaseStudies from "@/components/CaseStudies";
import CTA from "@/components/CTA";
import { campaigns } from "@/data/campaigns";
import { campaignStrategies, campaignServices, caseStudies } from "@/data/services";

export const metadata = {
  title: "Campaigns",
  description: "We build campaigns gaming audiences actually want to watch — and that move the metrics brands care about. Explore our work, strategy and case studies.",
  alternates: { canonical: "/campaigns" },
};

export default function CampaignsPage() {
  return (
    <>
      <section className="page-hero">
        <div className="page-hero__inner">
          <span className="page-hero__eyebrow">Campaign Strategy</span>
          <h1 className="page-hero__title gradtext">Campaigns<br />People <em>Remember.</em></h1>
          <p className="page-hero__sub">Attention is easy to buy and hard to earn. We build campaigns gaming audiences actually want to watch — and that move the metrics brands care about.</p>
        </div>
      </section>

      <section className="section">
        <div className="shell">
          <div className="split">
            <div className="split__media reveal is-visible">
              <Image src="https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=900&q=80&auto=format&fit=crop" alt="Campaign production" fill sizes="(max-width:1024px) 100vw, 50vw" />
            </div>
            <div className="split__body reveal is-visible d1">
              <p className="eyebrow">The Reason Behind Successful Campaigns</p>
              <h2 className="title gradtext">Planning Before<br />Posting.</h2>
              <p>Every campaign starts with the audience, not the asset. We map who a brand needs to reach, then select the creators whose communities already live there. Matching is everything — the wrong voice wastes the best budget.</p>
              <p>From there it's disciplined execution: clear creative direction, native formats per platform, and a measurement plan agreed before anything ships. No guesswork, no vanity metrics.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section section--alt glow">
        <div className="shell">
          <SectionHead eyebrow="Selected Work" title="Campaigns We<br>Have Created." />
          <CampaignGrid campaigns={campaigns} />
        </div>
      </section>

      <section className="section">
        <div className="shell">
          <SectionHead eyebrow="How We Work" title="Our Strategies<br>& Approach." />
          <Tiles items={campaignStrategies} />
        </div>
      </section>

      <section className="section section--alt glow">
        <div className="shell">
          <SectionHead eyebrow="In Detail" title="Recent Campaign<br>Case Studies." />
          <CaseStudies items={caseStudies} />
        </div>
      </section>

      <section className="section">
        <div className="shell">
          <SectionHead eyebrow="Beyond Campaigns" title="Other Services<br>We Provide." />
          <Tiles items={campaignServices} />
        </div>
      </section>

      <CTA eyebrow="Let's Build Together" title="Want To Launch<br>Your First Campaign?" sub="Tell us your goal and your audience. We'll bring the creators, the strategy and the numbers." button="Start A Campaign" />
    </>
  );
}
