import Image from "next/image";
import { SectionHead } from "@/components/Blocks";
import TeamGrid from "@/components/TeamGrid";
import FounderFeature from "@/components/FounderFeature";
import AboutSocials from "@/components/AboutSocials";
import CTA from "@/components/CTA";
import { team, founder } from "@/data/team";

export const metadata = {
  title: "About",
  description: "Influexa is a gaming-focused marketing and talent management agency built by people who came from the industry. Meet the founders and team.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  const rest = team.filter((m) => m.id !== founder.id);
  return (
    <>
      <section className="page-hero">
        <div className="page-hero__inner">
          <span className="page-hero__eyebrow">About Influexa</span>
          <h1 className="page-hero__title gradtext">Built For The<br />Way Gaming <em>Works.</em></h1>
          <p className="page-hero__sub">We're a gaming-focused marketing and talent management agency — built by people who came from the industry and got tired of watching creators treated like ad space.</p>
        </div>
      </section>

      <section className="section">
        <div className="shell">
          <div className="split">
            <div className="split__body reveal is-visible">
              <p className="eyebrow">What Is Influexa & Why Does It Exist?</p>
              <h2 className="title gradtext">A Different<br />Kind Of Agency.</h2>
              <p>Influexa exists because gaming audiences are the most engaged — and the most skeptical — on the internet. They can smell an inauthentic ad in seconds, and they punish brands that get it wrong.</p>
              <p>We were founded to bridge that gap: to help brands earn a place in gaming culture instead of buying their way in, and to give creators the management, protection and strategy they deserve.</p>
              <p>Our mission is simple — build campaigns and careers that last longer than a trend cycle.</p>
            </div>
            <div className="split__media reveal is-visible d1">
              <Image src="https://images.unsplash.com/photo-1511512578047-dfb367046420?w=900&q=80&auto=format&fit=crop" alt="The Influexa studio" fill sizes="(max-width:1024px) 100vw, 50vw" />
            </div>
          </div>
        </div>
      </section>

      {/* FOUNDER — prominent, near the top */}
      <section className="section section--alt glow">
        <div className="shell">
          <SectionHead eyebrow="Founder" title="The Person<br>Who Started It." />
          <FounderFeature member={founder} />
          <div style={{ marginTop: "8px" }}>
            <SectionHead eyebrow="The People" title="Who's Behind<br>Influexa." />
            <TeamGrid team={rest} />
          </div>
        </div>
      </section>

      <section className="section">
        <div className="shell" style={{ textAlign: "center" }}>
          <p className="eyebrow reveal is-visible">Social Presence</p>
          <h2 className="title gradtext reveal is-visible d1" style={{ marginBottom: "24px" }}>Where The<br />Community Lives.</h2>
          <p className="lead reveal is-visible d2" style={{ margin: "0 auto 44px" }}>We're active where gaming happens. Follow along for campaign drops, creator news and behind-the-scenes from the roster.</p>
          <AboutSocials />
        </div>
      </section>

      <CTA eyebrow="Work With Us" title="Let's Build<br>Something Real." sub="Brand, creator or freelancer — the conversation starts the same way." />
    </>
  );
}
