import Hero from "@/components/Hero";
import Ticker from "@/components/Ticker";
import { SectionHead, BrandGrid } from "@/components/Blocks";
import CampaignGrid from "@/components/CampaignGrid";
import TalentGrid from "@/components/TalentGrid";
import CTA from "@/components/CTA";
import { campaigns } from "@/data/campaigns";
import { brands } from "@/data/brands";
import { talents } from "@/data/talents";

export const metadata = {
  description: "Influexa connects gaming brands with creators capable of turning attention into community, engagement into trust, and campaigns into measurable growth.",
  alternates: { canonical: "/" },
};

export default function HomePage() {
  const featuredCampaigns = campaigns.filter((c) => c.featured);
  const featuredTalents = talents.filter((t) => t.featured).slice(0, 6);

  return (
    <>
      <Hero />
      <Ticker />

      <section className="section section--alt glow" id="campaigns">
        <div className="shell">
          <SectionHead eyebrow="What We've Built" title="Recent<br>Campaigns" link={{ href: "/campaigns", label: "View All Work →" }} />
          <CampaignGrid campaigns={featuredCampaigns} />
        </div>
      </section>

      <section className="section section--white" id="brands">
        <div className="shell">
          <h2 className="brands__hl reveal is-visible" style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: "clamp(42px,5.5vw,82px)", letterSpacing: ".02em", lineHeight: ".95", maxWidth: "720px", marginBottom: "72px", color: "#000" }}>
            Trusted By Brands<br />That Want <em style={{ fontFamily: "'Cormorant Garamond',serif", fontStyle: "italic", fontWeight: 300, fontSize: ".9em" }}>Real Attention.</em>
          </h2>
          <BrandGrid brands={brands} />
        </div>
      </section>

      <section className="section glow" id="creators">
        <div className="shell">
          <SectionHead eyebrow="The Network" title="Featured<br>Influencers" link={{ href: "/talent", label: "Full Roster →" }} />
          <TalentGrid talents={featuredTalents} />
        </div>
      </section>

      <CTA eyebrow="Let's Get To Work" title="Ready To Build A<br>Campaign People<br>Remember?" sub="Whether you're a gaming creator, freelancer, or brand — let's build something worth talking about." />
    </>
  );
}
