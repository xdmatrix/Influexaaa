import { Resend } from "resend";
import { site } from "@/data/site";
import { validateContact } from "@/lib/validate";
import { clean, cleanLine, escapeHtml } from "@/lib/sanitize";

export const runtime = "nodejs";

// Very small in-memory rate limit (per warm instance). For production scale,
// back this with Upstash/Redis. Keeps casual abuse down without external deps.
const HITS = new Map();
const WINDOW_MS = 60_000;
const MAX_PER_WINDOW = 5;

function rateLimited(ip) {
  const now = Date.now();
  const arr = (HITS.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  arr.push(now);
  HITS.set(ip, arr);
  return arr.length > MAX_PER_WINDOW;
}

export async function POST(req) {
  try {
    const ip =
      req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
      req.headers.get("x-real-ip") ||
      "unknown";

    if (rateLimited(ip)) {
      return Response.json({ error: "Too many requests. Please try again shortly." }, { status: 429 });
    }

    const body = await req.json().catch(() => ({}));

    // --- Spam protection: honeypot + timing trap ---
    if (body.company) {
      // Bots fill hidden field; pretend success so they don't retry.
      return Response.json({ ok: true });
    }
    if (typeof body.elapsedMs === "number" && body.elapsedMs < 1200) {
      return Response.json({ error: "Submission looks automated." }, { status: 400 });
    }

    // --- Validation ---
    const { ok, errors } = validateContact(body, site.contactCategories);
    if (!ok) {
      return Response.json({ error: "Please check the highlighted fields.", fields: errors }, { status: 400 });
    }

    // --- Sanitize ---
    const name = cleanLine(body.name, 80);
    const email = cleanLine(body.email, 120);
    const category = cleanLine(body.category, 40);
    const subjectRaw = cleanLine(body.subject, 120);
    const message = clean(body.message, 4000);
    const subject = `${category} - ${subjectRaw}`;

    const apiKey = process.env.RESEND_API_KEY;
    if (!apiKey) {
      return Response.json(
        { error: "Email service is not configured. Please email us directly." },
        { status: 500 }
      );
    }

    const resend = new Resend(apiKey);
    const from = process.env.CONTACT_FROM || "Influexa <onboarding@resend.dev>";
    const to = process.env.CONTACT_TO || site.email;

    const html = `
      <div style="font-family:Arial,sans-serif;font-size:14px;color:#111;line-height:1.6">
        <h2 style="margin:0 0 12px">New ${escapeHtml(category)} enquiry</h2>
        <p><strong>Name:</strong> ${escapeHtml(name)}<br/>
           <strong>Email:</strong> ${escapeHtml(email)}<br/>
           <strong>Category:</strong> ${escapeHtml(category)}</p>
        <p><strong>Subject:</strong> ${escapeHtml(subjectRaw)}</p>
        <p style="white-space:pre-wrap">${escapeHtml(message)}</p>
      </div>`;

    const { error } = await resend.emails.send({
      from,
      to,
      replyTo: email,
      subject,
      html,
      text: `Name: ${name}\nEmail: ${email}\nCategory: ${category}\nSubject: ${subjectRaw}\n\n${message}`,
    });

    if (error) {
      return Response.json({ error: "Could not send your message. Please try again." }, { status: 502 });
    }

    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ error: "Unexpected error. Please try again." }, { status: 500 });
  }
}
