/* ============================================================================
   FOUNDERS & TEAM  —  add / remove / edit people here.
   founder: true   → highlighted prominently near the top of the About page.
   skills          → shown as tags in the profile pop-up (fully editable).
   social          → optional; remove a line to hide that icon.
   ============================================================================ */
export const team = [
  {
    id: "daniel-mercer",
    name: "Daniel Mercer",
    role: "Founder & CEO",
    location: "London, UK",
    founder: true,
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80&auto=format&fit=crop",
    bio: "Daniel founded Influexa after a decade inside the gaming and esports industry, frustrated by agencies that treated creators as inventory. He leads brand strategy and the long-term vision for the roster.",
    skills: ["Brand Strategy", "Talent Management", "Partnerships", "Campaign Management"],
    social: { linkedin: "https://linkedin.com/", twitter: "https://x.com/", email: "mailto:daniel@influexa.org" },
  },
  {
    id: "sofia-almeida",
    name: "Sofia Almeida",
    role: "Head of Talent",
    location: "Lisbon, PT",
    founder: false,
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=800&q=80&auto=format&fit=crop",
    bio: "Sofia runs the talent division — scouting, development and the day-to-day support that keeps creators focused on their craft. She has personally managed careers from 50K to multi-million audiences.",
    skills: ["Talent Scouting", "Creator Development", "Negotiation", "Community"],
    social: { linkedin: "https://linkedin.com/", email: "mailto:sofia@influexa.org" },
  },
  {
    id: "marcus-lee",
    name: "Marcus Lee",
    role: "Campaign Director",
    location: "Singapore",
    founder: false,
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=800&q=80&auto=format&fit=crop",
    bio: "Marcus designs the campaign architecture behind every brand partnership, balancing creative ambition with measurable performance. He believes the best campaigns are the ones audiences don't realise are campaigns.",
    skills: ["Campaign Strategy", "Performance Marketing", "Creative Direction", "Analytics"],
    social: { linkedin: "https://linkedin.com/", twitter: "https://x.com/" },
  },
  {
    id: "priya-nair",
    name: "Priya Nair",
    role: "Head of Partnerships",
    location: "Dubai, UAE",
    founder: false,
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=800&q=80&auto=format&fit=crop",
    bio: "Priya owns the brand relationships, structuring deals that protect creator authenticity while delivering real value to partners. Her network spans the biggest names in gaming hardware and lifestyle.",
    skills: ["Brand Partnerships", "Deal Structuring", "Account Management", "Relationship Building"],
    social: { linkedin: "https://linkedin.com/", email: "mailto:priya@influexa.org" },
  },
];

export const founder = team.find((m) => m.founder) || team[0];
