/* ============================================================================
   SITE-WIDE CONTENT  —  edit company info, navigation, footer & social here.
   ============================================================================ */
export const site = {
  name: "Influexa",
  url: "https://influexa.org",
  email: "business@influexa.org",
  tagline: "Gaming Talent & Campaign Strategy",
  description:
    "Influexa is a gaming-focused marketing and talent management agency helping brands and creators build meaningful campaigns through creativity, strategy and performance.",

  /* Used in the footer left column */
  footerIntro:
    "Influexa is a gaming-focused marketing and talent management agency helping brands and creators build meaningful campaigns through creativity, strategy and performance.",

  /* Primary navigation (clean URLs, no .html) */
  nav: [
    { label: "Talent", href: "/talent" },
    { label: "Campaigns", href: "/campaigns" },
    { label: "About", href: "/about" },
  ],

  /* Footer navigation column — easy to edit/add */
  footerLinks: [
    { label: "Home", href: "/" },
    { label: "Talent", href: "/talent" },
    { label: "Campaigns", href: "/campaigns" },
    { label: "About", href: "/about" },
    { label: "Let's Connect", href: "/connect" },
  ],

  /* Social links — set to "" to hide one */
  social: {
    instagram: "https://instagram.com/",
    linkedin: "https://linkedin.com/",
    twitter: "https://x.com/",
    youtube: "https://youtube.com/",
    email: "mailto:business@influexa.org",
  },

  /* Connect form categories (the "I'm a" dropdown) */
  contactCategories: ["Business Admin", "Influencer"],
};
