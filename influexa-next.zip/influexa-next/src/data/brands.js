/* ============================================================================
   TRUSTED-BY BRANDS  —  add / remove / edit brands here.
   logo : path under /public (drop the official logo file there).
          Use the brand's REAL colored logo. SVG or PNG with transparency.
   url  : link to the brand (optional).
   ============================================================================ */
export const brands = [
  { name: "ExitLag",    logo: "/logos/exitlag.svg",   url: "https://www.exitlag.com",  category: "Optimization" },
  { name: "GearUp",     logo: "/logos/gearup.svg",    url: "#",                         category: "Boosting" },
  { name: "Hone",       logo: "/logos/hone.svg",      url: "#",                         category: "Performance" },
  { name: "Skin.Place", logo: "/logos/skinplace.svg", url: "#",                         category: "Marketplace" },
  { name: "SkinFlow",   logo: "/logos/skinflow.svg",  url: "#",                         category: "Marketplace" },
  // Add more brands by copying a line above and pointing logo to a new file.
];
