/* ============================================================================
   SERVICE LISTS & CASE STUDIES  —  edit copy / add items freely.
   ============================================================================ */
export const talentProvides = [
  { icon: "✦", name: "Sponsorship Opportunities", desc: "Curated brand deals matched to each creator's audience and voice." },
  { icon: "◈", name: "Brand Collaborations",      desc: "Long-term partnerships built on authenticity, not one-off placements." },
  { icon: "◻", name: "Content Strategy",          desc: "Editorial direction, formats and posting cadence that compound growth." },
  { icon: "⊞", name: "Contract Management",        desc: "We handle the paperwork, negotiation and legal so you create freely." },
  { icon: "⊕", name: "Growth Support",            desc: "Analytics, coaching and platform expertise to scale your audience." },
  { icon: "◯", name: "Campaign Negotiation",      desc: "We secure the rates and terms you deserve — and protect your time." },
];

export const talentManagement = [
  { icon: "✦", name: "Creator Support",     desc: "Day-to-day backing so creators can focus entirely on the craft." },
  { icon: "◈", name: "Growth Strategy",     desc: "Data-led direction on formats, cadence and platforms that compound." },
  { icon: "◻", name: "Brand Partnerships",  desc: "Deals matched to voice and values — never a trust-breaking placement." },
  { icon: "⊞", name: "Long-Term Management",desc: "We build careers across years, not campaigns across weeks." },
  { icon: "⊕", name: "Performance Insight", desc: "Transparent analytics that show what's working and what's next." },
  { icon: "◯", name: "Creative Direction",  desc: "Editorial and production guidance to keep output sharp and on-brand." },
];

export const campaignStrategies = [
  { icon: "✦", name: "Influencer Marketing", desc: "Creator-led storytelling that earns attention instead of buying it." },
  { icon: "◈", name: "Content Distribution", desc: "The right message, cut for every platform's native language." },
  { icon: "◻", name: "Community Activation", desc: "Turning passive audiences into participants who carry the message." },
  { icon: "⊞", name: "Performance Tracking", desc: "Transparent reporting on the metrics that map to business outcomes." },
  { icon: "⊕", name: "Paid Amplification",   desc: "Selective spend behind content that's already proving itself organically." },
];

export const campaignServices = [
  { icon: "✦", name: "Ad Management",      desc: "End-to-end paid media built around creator content." },
  { icon: "◈", name: "Talent Management",  desc: "Full representation for gaming creators and personalities." },
  { icon: "◻", name: "Brand Partnerships", desc: "Premium deal structuring between brands and our network." },
  { icon: "⊞", name: "Creator Marketing",  desc: "Campaigns designed natively for the creator economy." },
  { icon: "⊕", name: "Consultation",       desc: "Strategy sessions for brands entering gaming for the first time." },
];

export const caseStudies = [
  {
    id: "razer-movement",
    title: "Turning A Launch Into A Movement",
    brand: "Razer · Peripherals",
    summary: "A six-week creator-led launch built around authentic daily use rather than scripted ads. We matched five creators to distinct audience segments and let each tell the product story in their own voice.",
    detail: "Rather than a single hero asset, the campaign ran as five parallel narratives. Each creator received creative latitude within a shared brand frame, so the product appeared organically across very different content styles — from competitive FPS to cozy lifestyle streams. The result compounded: audiences saw the product repeatedly, in trusted contexts, without it ever reading as an ad.",
    image: "https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=1000&q=80&auto=format&fit=crop",
    metrics: [ { value: "18M", label: "Impressions" }, { value: "340%", label: "Engagement Lift" }, { value: "5", label: "Creators" } ],
  },
  {
    id: "amd-trust",
    title: "Building Trust Before Selling",
    brand: "AMD · Hardware",
    summary: "Instead of pushing specs, we ran a community-first campaign where creators documented real build journeys. Trust came first; conversions followed without a hard sell.",
    detail: "We sequenced the campaign so that value and transparency preceded any call to action. Creators shared genuine build experiences — including trade-offs — which earned credibility with a skeptical hardware audience. By the time offers appeared, the audience had already decided the brand was trustworthy.",
    image: "https://images.unsplash.com/photo-1591488320449-011701bb6704?w=1000&q=80&auto=format&fit=crop",
    metrics: [ { value: "9.2M", label: "Reach" }, { value: "4.4%", label: "Avg. Engagement" }, { value: "22K", label: "New Followers" } ],
  },
  {
    id: "steelseries-eventday",
    title: "Owning Event Day Across Twelve Voices",
    brand: "SteelSeries · Esports",
    summary: "A coordinated multi-creator push timed to a major tournament. Twelve creators covered the same event from twelve angles, saturating the conversation for 72 hours.",
    detail: "The operation was choreographed down to the hour. Twelve creators were briefed on complementary angles so coverage never felt repetitive, and posting windows were staggered to maintain a constant presence in feeds throughout the tournament weekend.",
    image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1000&q=80&auto=format&fit=crop",
    metrics: [ { value: "24M", label: "Views" }, { value: "12", label: "Creators" }, { value: "72h", label: "Peak Window" } ],
  },
];
