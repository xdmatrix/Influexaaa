/* ============================================================================
   CAMPAIGNS  —  add / remove / edit campaigns here (single source of truth).
   size:      "lg" = big tile, "sm" = small tile (used on the grid)
   featured:  true → also shows in the home "Recent Campaigns" grid
   The fields below the divider only appear inside the click-to-open pop-up.
   ============================================================================ */
export const campaigns = [
  {
    id: "razer-nightowl",
    brand: "Razer × NightOwl Studios",
    creator: "NightOwlGG & 4 partners",
    goal: "Product launch awareness",
    results: "18M Impressions · 340% Engagement Lift",
    image: "https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=1000&q=80&auto=format&fit=crop",
    size: "lg",
    featured: true,
    // ---- pop-up detail ----
    duration: "6 weeks",
    platforms: "YouTube · Twitch · TikTok",
    description:
      "A six-week creator-led launch built around authentic daily use rather than scripted ads. We matched five creators to distinct audience segments and let each tell the product story in their own voice.",
    objectives: [
      "Drive awareness for a new peripheral line",
      "Reach five distinct gaming sub-audiences",
      "Make the launch feel like culture, not advertising",
    ],
    metrics: [
      { value: "18M", label: "Impressions" },
      { value: "340%", label: "Engagement Lift" },
      { value: "5", label: "Creators" },
    ],
    gallery: [
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=900&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=900&q=80&auto=format&fit=crop",
    ],
  },
  {
    id: "amd-streamcore",
    brand: "AMD × StreamCore",
    creator: "StreamCore collective",
    goal: "Community trust campaign",
    results: "9.2M Reach",
    image: "https://images.unsplash.com/photo-1607016284318-d1384bf0b13d?w=900&q=80&auto=format&fit=crop",
    size: "sm",
    featured: true,
    duration: "4 weeks",
    platforms: "Twitch · X / Twitter",
    description:
      "Instead of pushing specs, we ran a community-first campaign where creators documented real build journeys. Trust came first; conversions followed without a single hard sell.",
    objectives: ["Build long-term brand trust", "Document authentic build journeys", "Grow creator audiences alongside the brand"],
    metrics: [
      { value: "9.2M", label: "Reach" },
      { value: "4.4%", label: "Avg. Engagement" },
      { value: "22K", label: "New Followers" },
    ],
    gallery: [],
  },
  {
    id: "steelseries-collective",
    brand: "SteelSeries × Creator Collective",
    creator: "12 creators",
    goal: "Esports audience penetration",
    results: "24M Views · 12 Creators",
    image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=900&q=80&auto=format&fit=crop",
    size: "sm",
    featured: true,
    duration: "72 hours",
    platforms: "YouTube · Twitch",
    description:
      "A coordinated multi-creator push timed to a major tournament. Twelve creators covered the same event from twelve angles, saturating the conversation for 72 hours straight.",
    objectives: ["Own the conversation around a major final", "Coordinate twelve creators in one window", "Penetrate the core esports audience"],
    metrics: [
      { value: "24M", label: "Views" },
      { value: "12", label: "Creators" },
      { value: "72h", label: "Peak Window" },
    ],
    gallery: [],
  },
  {
    id: "logitech-ariaplay",
    brand: "Logitech G × Aria.Play",
    creator: "Aria.Play",
    goal: "Peripheral series launch",
    results: "11.6M Reach · 4.1% CTR",
    image: "https://images.unsplash.com/photo-1542751110-97427bbecf20?w=900&q=80&auto=format&fit=crop",
    size: "sm",
    featured: false,
    duration: "5 weeks",
    platforms: "YouTube · Instagram",
    description:
      "A single-creator deep partnership pairing Aria.Play's lifestyle audience with a new peripheral line. Long-form reviews plus short-form cut-downs drove both awareness and click-through.",
    objectives: ["Launch a peripheral series", "Blend long-form and short-form", "Drive measurable click-through"],
    metrics: [
      { value: "11.6M", label: "Reach" },
      { value: "4.1%", label: "CTR" },
      { value: "5wk", label: "Duration" },
    ],
    gallery: [],
  },
  {
    id: "secretlab-veritasx",
    brand: "Secretlab × VeritasX",
    creator: "VeritasX",
    goal: "Event-day activation",
    results: "6.8M Reach · 38K Conversions",
    image: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=900&q=80&auto=format&fit=crop",
    size: "sm",
    featured: false,
    duration: "1 weekend",
    platforms: "Twitch · X / Twitter",
    description:
      "An event-day activation timed to a major esports final, turning VeritasX's live audience into a measurable conversion spike with a creator-exclusive offer.",
    objectives: ["Convert a live event audience", "Deploy a creator-exclusive offer", "Measure same-weekend impact"],
    metrics: [
      { value: "6.8M", label: "Reach" },
      { value: "38K", label: "Conversions" },
      { value: "1", label: "Weekend" },
    ],
    gallery: [],
  },
];
