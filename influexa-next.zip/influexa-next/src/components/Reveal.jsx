"use client";
import { useEffect, useRef, useState } from "react";

/* Wraps children and fades them in on scroll. Falls back to visible. */
export default function Reveal({ children, className = "", delay = 0, as: Tag = "div" }) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || !("IntersectionObserver" in window)) { setVisible(true); return; }
    const node = ref.current;
    if (!node) return;
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) { setVisible(true); io.unobserve(e.target); } }),
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );
    io.observe(node);
    const t = setTimeout(() => setVisible(true), 3000); // safety
    return () => { io.disconnect(); clearTimeout(t); };
  }, []);

  const delayCls = delay ? ` d${delay}` : "";
  return (
    <Tag ref={ref} className={`reveal${visible ? " is-visible" : ""}${delayCls} ${className}`.trim()}>
      {children}
    </Tag>
  );
}
