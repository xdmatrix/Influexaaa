"use client";
import Image from "next/image";
import { useModal } from "./ModalProvider";

export default function CampaignGrid({ campaigns }) {
  const { openCampaign } = useModal();
  return (
    <div className="camp-grid">
      {campaigns.map((c) => {
        const cls = "camp " + (c.size === "lg" ? "camp--lg" : "camp--sm") + " reveal is-visible";
        return (
          <article
            className={cls}
            key={c.id || c.brand}
            role="button"
            tabIndex={0}
            aria-label={`View ${c.brand} campaign details`}
            onClick={() => openCampaign(c)}
            onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openCampaign(c); } }}
          >
            <Image className="camp__img" src={c.image} alt={`${c.brand} campaign`} fill
              sizes="(max-width:1024px) 100vw, 50vw" />
            <div className="camp__overlay" />
            <span className="camp__view">View Case +</span>
            <div className="camp__info">
              <p className="camp__tag">{c.brand}</p>
              <h3 className="camp__name">{c.goal}</h3>
              <p className="camp__meta">Creator: {c.creator}</p>
              <span className="camp__result">↑ {c.results}</span>
            </div>
          </article>
        );
      })}
    </div>
  );
}
