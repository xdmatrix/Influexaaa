"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { site } from "@/data/site";
import { useModal } from "./ModalProvider";

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [menu, setMenu] = useState(false);
  const pathname = usePathname();
  const { openConnect } = useModal();

  useEffect(() => {
    let ticking = false;
    const onScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          setScrolled(window.pageYOffset > 60);
          ticking = false;
        });
        ticking = true;
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menu ? "hidden" : "";
    const onKey = (e) => e.key === "Escape" && setMenu(false);
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [menu]);

  const isActive = (href) => pathname === href;

  return (
    <>
      <header className={"nav" + (scrolled ? " is-scrolled" : "")}>
        <nav className="nav__group" aria-label="Primary left">
          <Link className={"nav__link" + (isActive("/talent") ? " is-active" : "")} href="/talent">Talent</Link>
          <Link className={"nav__link" + (isActive("/campaigns") ? " is-active" : "")} href="/campaigns">Campaigns</Link>
        </nav>

        <Link className="nav__logo" href="/" aria-label="Influexa home">Influexa</Link>

        <div className="nav__right">
          <nav className="nav__group" aria-label="Primary right">
            <Link className={"nav__link" + (isActive("/about") ? " is-active" : "")} href="/about">About</Link>
          </nav>
          <button className="nav__cta" onClick={openConnect}>Let&apos;s Connect</button>
          <button className={"nav__burger" + (menu ? " is-open" : "")} aria-label="Open menu"
            aria-expanded={menu} onClick={() => setMenu(true)}>
            <span></span><span></span><span></span>
          </button>
        </div>
      </header>

      {/* Small CENTERED popup menu (mobile) */}
      <div className={"mmenu" + (menu ? " is-open" : "")} role="dialog" aria-modal="true" aria-label="Menu">
        <div className="mmenu__backdrop" onClick={() => setMenu(false)} />
        <div className="mmenu__panel">
          <div className="mmenu__head">
            <span className="mmenu__logo">Influexa</span>
            <button className="mmenu__close" onClick={() => setMenu(false)} aria-label="Close menu">&times;</button>
          </div>
          <div className="mmenu__links">
            <Link className="mmenu__link" href="/" onClick={() => setMenu(false)}>Home</Link>
            <Link className="mmenu__link" href="/talent" onClick={() => setMenu(false)}>Talent</Link>
            <Link className="mmenu__link" href="/campaigns" onClick={() => setMenu(false)}>Campaigns</Link>
            <Link className="mmenu__link" href="/about" onClick={() => setMenu(false)}>About</Link>
          </div>
          <button className="btn btn--white mmenu__cta" onClick={() => { setMenu(false); openConnect(); }}>
            Let&apos;s Connect
          </button>
        </div>
      </div>
    </>
  );
}
