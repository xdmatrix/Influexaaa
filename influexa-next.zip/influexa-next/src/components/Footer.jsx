"use client";
import Link from "next/link";
import { site } from "@/data/site";
import { Icon } from "./Icons";
import { useModal } from "./ModalProvider";

export default function Footer() {
  const { openConnect } = useModal();
  const s = site.social || {};
  const socials = [
    ["instagram", "Instagram", s.instagram],
    ["linkedin", "LinkedIn", s.linkedin],
    ["twitter", "X / Twitter", s.twitter],
    ["youtube", "YouTube", s.youtube],
    ["email", "Email", s.email],
  ].filter((x) => x[2]);

  return (
    <footer className="footer">
      <div className="footer__grid">
        <div className="footer__brand-col">
          <Link className="footer__brand gradtext" href="/">Influexa</Link>
          <p className="footer__intro">{site.footerIntro}</p>
        </div>
        <div>
          <p className="footer__col-title">Navigation</p>
          <div className="footer__links">
            {site.footerLinks.map((l) =>
              l.href === "/connect" ? (
                <a key={l.label} href="/connect" onClick={(e) => { e.preventDefault(); openConnect(); }}>{l.label}</a>
              ) : (
                <Link key={l.label} href={l.href}>{l.label}</Link>
              )
            )}
          </div>
        </div>
        <div>
          <p className="footer__col-title">Connect</p>
          <div className="footer__socials">
            {socials.map(([key, label, href]) => (
              <a className="footer__social" key={key} href={href}
                 target={key === "email" ? undefined : "_blank"} rel="noopener noreferrer">
                <span className="footer__social-ic"><Icon name={key} /></span>
                <span>{label}</span>
              </a>
            ))}
          </div>
        </div>
      </div>
      <div className="footer__bottom">
        <span className="footer__copy">© {new Date().getFullYear()} Influexa. All rights reserved.</span>
        <span className="footer__copy">Gaming Talent &amp; Campaign Strategy</span>
      </div>
    </footer>
  );
}
