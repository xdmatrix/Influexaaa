import Image from "next/image";

export default function TalentGrid({ talents }) {
  return (
    <div className="cr-grid">
      {talents.map((t, i) => (
        <article className={"cr reveal is-visible d" + ((i % 3) + 1)} key={t.id || t.name}>
          <Image className="cr__img" src={t.image} alt={`${t.name} — ${t.category}`} fill sizes="(max-width:680px) 100vw, (max-width:1024px) 50vw, 33vw" />
          <div className="cr__overlay" />
          <div className="cr__info">
            <p className="cr__cat">{t.category}</p>
            <h3 className="cr__name">{t.name}</h3>
            {t.specialty && <p className="cr__spec">{t.specialty}</p>}
            <div className="cr__stats">
              <span className="cr__stat"><strong>{t.followers}</strong> Followers</span>
              <span className="cr__stat"><strong>{t.engagement}</strong> Engagement</span>
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}
