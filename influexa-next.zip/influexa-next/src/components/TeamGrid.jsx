"use client";
import Image from "next/image";
import { useModal } from "./ModalProvider";

export default function TeamGrid({ team }) {
  const { openTeam } = useModal();
  return (
    <div className="team-grid">
      {team.map((m, i) => (
        <article className={"member reveal is-visible d" + ((i % 4) + 1)} key={m.id || m.name}>
          <button className="member__media" onClick={() => openTeam(m)}
            aria-label={`View ${m.name}'s profile`} style={{ display: "block", width: "100%", border: 0, padding: 0, cursor: "pointer", background: "none" }}>
            <Image src={m.image} alt={`Portrait of ${m.name}, ${m.role}`} fill sizes="(max-width:680px) 100vw, (max-width:1024px) 50vw, 25vw" />
          </button>
          <div className="member__body">
            <h3 className="member__name">{m.name}</h3>
            <p className="member__role">{m.role}</p>
            <button className="member__more" onClick={() => openTeam(m)}>View More <span>→</span></button>
          </div>
        </article>
      ))}
    </div>
  );
}
