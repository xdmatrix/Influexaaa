"use client";
import { createContext, useContext, useState, useEffect, useCallback } from "react";
import ConnectForm from "./ConnectForm";
import { Icon } from "./Icons";

const ModalCtx = createContext(null);
export const useModal = () => useContext(ModalCtx);

export default function ModalProvider({ children }) {
  const [modal, setModal] = useState(null); // {type, data}

  const close = useCallback(() => setModal(null), []);
  const openConnect = useCallback(() => setModal({ type: "connect" }), []);
  const openTeam = useCallback((m) => setModal({ type: "team", data: m }), []);
  const openCampaign = useCallback((c) => setModal({ type: "campaign", data: c }), []);
  const openCase = useCallback((c) => setModal({ type: "case", data: c }), []);

  useEffect(() => {
    function onKey(e) { if (e.key === "Escape") close(); }
    if (modal) {
      document.addEventListener("keydown", onKey);
      document.body.style.overflow = "hidden";
    }
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [modal, close]);

  return (
    <ModalCtx.Provider value={{ openConnect, openTeam, openCampaign, openCase, close }}>
      {children}
      <Modal modal={modal} close={close} />
    </ModalCtx.Provider>
  );
}

function Modal({ modal, close }) {
  const wide = modal && modal.type !== "connect";
  return (
    <div className={"modal" + (modal ? " is-open" : "")} role="dialog" aria-modal="true">
      <div className="modal__backdrop" onClick={close} />
      <div className={"modal__panel" + (wide ? " modal__panel--wide" : "")}>
        {modal && (
          <>
            <button className="modal__close" onClick={close} aria-label="Close">&times;</button>
            {modal.type === "connect" && <ConnectBody close={close} />}
            {modal.type === "team" && <TeamBody m={modal.data} />}
            {modal.type === "campaign" && <CampaignBody c={modal.data} close={close} />}
            {modal.type === "case" && <CaseBody c={modal.data} />}
          </>
        )}
      </div>
    </div>
  );
}

function ConnectBody({ close }) {
  return (
    <>
      <p className="modal__eyebrow">Let&apos;s Connect</p>
      <h2 className="modal__title">Start A Conversation</h2>
      <p className="modal__sub">Tell us who you are and what you&apos;re building. We reply to every serious inquiry within two business days.</p>
      <ConnectForm onSuccess={() => setTimeout(close, 1600)} />
    </>
  );
}

function TeamBody({ m }) {
  if (!m) return null;
  const socials = m.social || {};
  const order = ["linkedin", "twitter", "instagram", "youtube", "email"];
  return (
    <div className="profile">
      <img className="profile__img" src={m.image} alt={`Portrait of ${m.name}`} />
      <div>
        <p className="profile__role">{m.role}</p>
        <h2 className="profile__name">{m.name}</h2>
        {m.location && <p className="profile__loc">{m.location}</p>}
        {Array.isArray(m.skills) && m.skills.length > 0 && (
          <>
            <p className="profile__skills-title">Skills</p>
            <div className="profile__skills">
              {m.skills.map((s) => <span className="skill-tag" key={s}>{s}</span>)}
            </div>
          </>
        )}
        <p className="profile__bio" style={{ marginTop: "22px" }}>{m.bio}</p>
        {Object.keys(socials).length > 0 && (
          <div className="profile__socials">
            {order.filter((k) => socials[k]).map((k) => (
              <a className="profile__social" key={k} href={socials[k]}
                 target={k === "email" ? undefined : "_blank"} rel="noopener noreferrer"
                 aria-label={`${m.name} on ${k}`}>
                <Icon name={k} />
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function CampaignBody({ c, close }) {
  if (!c) return null;
  const gallery = (c.gallery || []).filter(Boolean);
  return (
    <div className="cmodal">
      <div className="cmodal__hero"><img src={c.image} alt={`${c.brand} campaign`} /></div>
      <p className="modal__eyebrow">{c.brand}</p>
      <h2 className="modal__title">{c.goal}</h2>
      {c.description && <p className="modal__sub">{c.description}</p>}

      <div className="cmodal__facts">
        {c.creator && <div className="cmodal__fact"><span>Creator</span><b>{c.creator}</b></div>}
        {c.duration && <div className="cmodal__fact"><span>Duration</span><b>{c.duration}</b></div>}
        {c.platforms && <div className="cmodal__fact"><span>Platforms</span><b>{c.platforms}</b></div>}
      </div>

      {Array.isArray(c.objectives) && c.objectives.length > 0 && (
        <>
          <p className="profile__skills-title">Objectives</p>
          <div className="profile__skills" style={{ marginBottom: "22px" }}>
            {c.objectives.map((o) => <span className="skill-tag" key={o}>{o}</span>)}
          </div>
        </>
      )}

      {Array.isArray(c.metrics) && c.metrics.length > 0 && (
        <div className="case__metrics cmodal__metrics">
          {c.metrics.map((m) => (
            <div className="case__metric" key={m.label}><b>{m.value}</b><span>{m.label}</span></div>
          ))}
        </div>
      )}

      {gallery.length > 0 && (
        <div className="cmodal__gallery">
          {gallery.map((g, i) => <img key={i} src={g} alt={`${c.brand} campaign image ${i + 1}`} loading="lazy" />)}
        </div>
      )}

      <div className="cmodal__cta">
        <button className="btn btn--white btn--lg" onClick={close}>Close</button>
      </div>
    </div>
  );
}

function CaseBody({ c }) {
  if (!c) return null;
  return (
    <div className="cmodal">
      <div className="cmodal__hero"><img src={c.image} alt={`${c.brand} case study`} /></div>
      <p className="modal__eyebrow">{c.brand}</p>
      <h2 className="modal__title">{c.title}</h2>
      {c.summary && <p className="modal__sub">{c.summary}</p>}
      {c.detail && <p className="profile__bio" style={{ marginBottom: "24px" }}>{c.detail}</p>}
      {Array.isArray(c.metrics) && c.metrics.length > 0 && (
        <div className="case__metrics cmodal__metrics">
          {c.metrics.map((m) => (
            <div className="case__metric" key={m.label}><b>{m.value}</b><span>{m.label}</span></div>
          ))}
        </div>
      )}
    </div>
  );
}
