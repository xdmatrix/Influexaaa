const ITEMS = ["Gaming Creators","Esports Campaigns","Brand Partnerships","Talent Management","Community Strategy","Content Direction","Measurable Growth"];
export default function Ticker() {
  const row = [...ITEMS, ...ITEMS];
  return (
    <div className="ticker" aria-hidden="true">
      <div className="ticker__track">
        {row.map((t, i) => (
          <span key={i}>{t}<span className="sep" style={{ marginLeft: "0" }}> · </span></span>
        ))}
      </div>
    </div>
  );
}
