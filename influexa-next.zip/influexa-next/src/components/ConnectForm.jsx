"use client";
import { useState, useRef } from "react";
import { site } from "@/data/site";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function ConnectForm({ onSuccess }) {
  const [values, setValues] = useState({
    name: "",
    email: "",
    category: site.contactCategories[0],
    subject: "",
    message: "",
    company: "", // honeypot (must stay empty)
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState({ state: "idle", msg: "" });
  const startedAt = useRef(Date.now());

  function setField(k, v) {
    setValues((s) => ({ ...s, [k]: v }));
    if (errors[k]) setErrors((e) => ({ ...e, [k]: "" }));
  }

  function validate() {
    const e = {};
    if (!values.name.trim()) e.name = "Please enter your name.";
    else if (values.name.trim().length > 80) e.name = "Name is too long.";
    if (!values.email.trim()) e.email = "Please enter your email.";
    else if (!EMAIL_RE.test(values.email.trim())) e.email = "Enter a valid email address.";
    if (!values.subject.trim()) e.subject = "Please add a subject.";
    else if (values.subject.trim().length > 120) e.subject = "Subject is too long.";
    if (!values.message.trim()) e.message = "Please write a short message.";
    else if (values.message.trim().length > 4000) e.message = "Message is too long.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(ev) {
    ev.preventDefault();
    if (status.state === "loading") return;
    if (!validate()) return;

    setStatus({ state: "loading", msg: "" });
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...values, elapsedMs: Date.now() - startedAt.current }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Something went wrong. Please try again.");
      setStatus({ state: "ok", msg: "Message sent — we'll be in touch within two business days." });
      setValues((s) => ({ ...s, name: "", email: "", subject: "", message: "" }));
      if (onSuccess) onSuccess();
    } catch (err) {
      setStatus({ state: "error", msg: err.message || "Could not send. Please email us directly." });
    }
  }

  const formattedSubject =
    values.subject.trim() ? `${values.category} - ${values.subject.trim()}` : "";

  return (
    <form className="form" onSubmit={handleSubmit} noValidate>
      {/* Honeypot — hidden from humans, bots fill it */}
      <div className="hp-field" aria-hidden="true">
        <label htmlFor="cf-company">Company</label>
        <input
          id="cf-company"
          name="company"
          tabIndex={-1}
          autoComplete="off"
          value={values.company}
          onChange={(e) => setField("company", e.target.value)}
        />
      </div>

      <div className="form__row">
        <div className={"field" + (errors.name ? " field--error" : "")}>
          <label htmlFor="cf-name">Name</label>
          <input id="cf-name" type="text" placeholder="Your full name" value={values.name}
            maxLength={80} onChange={(e) => setField("name", e.target.value)} required />
          {errors.name && <span className="field__err">{errors.name}</span>}
        </div>
        <div className={"field" + (errors.email ? " field--error" : "")}>
          <label htmlFor="cf-email">Email</label>
          <input id="cf-email" type="email" placeholder="you@email.com" value={values.email}
            maxLength={120} onChange={(e) => setField("email", e.target.value)} required />
          {errors.email && <span className="field__err">{errors.email}</span>}
        </div>
      </div>

      <div className="field">
        <label htmlFor="cf-cat">I'm a…</label>
        <select id="cf-cat" value={values.category} onChange={(e) => setField("category", e.target.value)}>
          {site.contactCategories.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>

      <div className={"field" + (errors.subject ? " field--error" : "")}>
        <label htmlFor="cf-subject">Subject</label>
        <input id="cf-subject" type="text" placeholder="e.g. Partnership Inquiry" value={values.subject}
          maxLength={120} onChange={(e) => setField("subject", e.target.value)} required />
        {errors.subject && <span className="field__err">{errors.subject}</span>}
      </div>

      <div className={"field" + (errors.message ? " field--error" : "")}>
        <label htmlFor="cf-msg">Message</label>
        <textarea id="cf-msg" placeholder="A few sentences about what you have in mind…" value={values.message}
          maxLength={4000} onChange={(e) => setField("message", e.target.value)} required />
        {errors.message && <span className="field__err">{errors.message}</span>}
      </div>

      {formattedSubject && (
        <p className="form__preview">Sent as: <b>{formattedSubject}</b></p>
      )}

      {status.state === "ok" && <div className="form__status form__status--ok">{status.msg}</div>}
      {status.state === "error" && <div className="form__status form__status--err">{status.msg}</div>}

      <button className="btn btn--white btn--lg form__submit" type="submit" disabled={status.state === "loading"}>
        {status.state === "loading" ? <><span className="spinner" />Sending…</> : "Send Message"}
      </button>
      <p className="form__note">Your message is delivered securely to {site.email}.</p>
    </form>
  );
}
