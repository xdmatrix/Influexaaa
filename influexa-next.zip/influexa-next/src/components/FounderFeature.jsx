"use client";
import Image from "next/image";
import { useModal } from "./ModalProvider";

export default function FounderFeature({ member }) {
  const { openTeam } = useModal();
  if (!member) return null;
  return (
    <div className="founder reveal is-visible">
      <button className="founder__media" onClick={() => openTeam(member)}
        aria-label={`View ${member.name}'s full profile`}
        style={{ border: 0, padding: 0, cursor: "pointer", background: "none" }}>
        <Image src={member.image} alt={`Portrait of ${member.name}, ${member.role}`} fill sizes="(max-width:760px) 100vw, 40vw" />
      </button>
      <div>
        <span className="founder__tag">Founder</span>
        <h3 className="founder__name">{member.name}</h3>
        <p className="founder__role">{member.role}{member.location ? ` · ${member.location}` : ""}</p>
        <p className="founder__bio">{member.bio}</p>
        <button className="btn btn--ghost" onClick={() => openTeam(member)}>View Full Profile</button>
      </div>
    </div>
  );
}
