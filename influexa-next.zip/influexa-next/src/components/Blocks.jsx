import Image from "next/image";

export function SectionHead({ eyebrow, title, link }) {
  return (
    <div className="sec-head reveal is-visible">
      <div>
        {eyebrow && <p className="eyebrow">{eyebrow}</p>}
        <h2 className="title gradtext" dangerouslySetInnerHTML={{ __html: title }} />
      </div>
      {link && <a className="seclink" href={link.href}>{link.label}</a>}
    </div>
  );
}

export function Tiles({ items }) {
  return (
    <div className="tiles">
      {items.map((t, i) => (
        <div className={"tile reveal is-visible d" + ((i % 3) + 1)} key={t.name}>
          <div className="tile__icon" aria-hidden="true">{t.icon}</div>
          <h3 className="tile__name">{t.name}</h3>
          <p className="tile__desc">{t.desc}</p>
        </div>
      ))}
    </div>
  );
}

export function BrandGrid({ brands }) {
  return (
    <div className="brands__grid">
      {brands.map((b) => (
        <a className="brand" key={b.name} href={b.url || "#"} target={b.url && b.url !== "#" ? "_blank" : undefined}
           rel="noopener noreferrer" aria-label={b.name} title={b.name}>
          {/* Plain img for small SVG logos (already optimized, original colors) */}
          <img className="brand__logo" src={b.logo} alt={`${b.name} logo`} loading="lazy" width="140" height="42" />
        </a>
      ))}
    </div>
  );
}
