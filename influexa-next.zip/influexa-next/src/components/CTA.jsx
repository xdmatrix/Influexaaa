"use client";
import { useModal } from "./ModalProvider";

export default function CTA({ eyebrow, title, sub, button = "Let's Connect" }) {
  const { openConnect } = useModal();
  return (
    <section className="cta">
      <div className="cta__inner">
        <p className="cta__eyebrow reveal is-visible">{eyebrow}</p>
        <h2 className="cta__hl reveal is-visible d1 gradtext" dangerouslySetInnerHTML={{ __html: title }} />
        {sub && <p className="cta__sub reveal is-visible d2">{sub}</p>}
        <div className="reveal is-visible d3">
          <button className="btn btn--white btn--lg" onClick={openConnect}>{button}</button>
        </div>
      </div>
    </section>
  );
}
