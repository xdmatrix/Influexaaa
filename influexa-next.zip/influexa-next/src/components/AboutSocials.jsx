"use client";
import { site } from "@/data/site";

export default function AboutSocials() {
  const s = site.social || {};
  const items = [
    ["Instagram", s.instagram], ["LinkedIn", s.linkedin],
    ["X / Twitter", s.twitter], ["YouTube", s.youtube], ["Email", s.email],
  ].filter((x) => x[1]);
  return (
    <div className="reveal is-visible d3" style={{ display: "flex", gap: "14px", justifyContent: "center", flexWrap: "wrap" }}>
      {items.map(([label, href]) => (
        <a key={label} className="btn btn--ghost" href={href}
           target={href.startsWith("mailto") ? undefined : "_blank"} rel="noopener noreferrer">{label}</a>
      ))}
    </div>
  );
}
