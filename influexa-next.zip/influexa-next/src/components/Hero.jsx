"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useModal } from "./ModalProvider";

export default function Hero() {
  const { openConnect } = useModal();
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const id = requestAnimationFrame(() => setLoaded(true));
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let ticking = false;
    const wrap = document.getElementById("heroParallax");
    const onScroll = () => {
      if (reduce || !wrap) return;
      if (!ticking) {
        requestAnimationFrame(() => {
          wrap.style.transform = `translate3d(0,${window.pageYOffset * 0.18}px,0)`;
          ticking = false;
        });
        ticking = true;
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => { cancelAnimationFrame(id); window.removeEventListener("scroll", onScroll); };
  }, []);

  return (
    <section className={"hero" + (loaded ? " is-loaded" : "")}>
      <div className="hero__bgwrap" id="heroParallax"><div className="hero__bg" /></div>
      <div className="hero__inner">
        <div className="hero__left">
          <span className="hero__eyebrow">Gaming Talent Management &amp; Campaigns</span>
          <h1 className="hero__hl">
            <span className="a gradtext">Gaming Audiences</span>
            <span className="a gradtext">Don&apos;t Follow Ads.</span>
            <span className="b">They Follow Stories.</span>
          </h1>
          <p className="hero__sub">Influexa connects gaming brands with creators capable of turning attention into community, engagement into trust, and campaigns into measurable growth.</p>
          <div className="hero__btns">
            <button className="btn btn--white" onClick={openConnect}>Start Campaign</button>
            <Link className="btn btn--ghost" href="/talent">Explore Talent</Link>
          </div>
        </div>
        <div className="hero__cards">
          <div className="statcard"><div className="statcard__num gradtext">50M+</div><div className="statcard__label">Reach Generated</div></div>
          <div className="statcard"><div className="statcard__num gradtext">100+</div><div className="statcard__label">Gaming Creators</div></div>
          <div className="statcard"><div className="statcard__num gradtext">20+</div><div className="statcard__label">Partner Brands</div></div>
        </div>
      </div>
      <div className="scroll-ind"><span className="scroll-ind__line" /><span className="scroll-ind__txt">Scroll</span></div>
    </section>
  );
}
