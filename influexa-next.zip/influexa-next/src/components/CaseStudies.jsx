"use client";
import Image from "next/image";
import { useModal } from "./ModalProvider";

export default function CaseStudies({ items }) {
  const { openCase } = useModal();
  return (
    <div className="cases">
      {items.map((c) => (
        <article className="case reveal is-visible" key={c.id || c.title}>
          <div className="case__media">
            <Image src={c.image} alt={`${c.title} — ${c.brand}`} fill sizes="(max-width:1024px) 100vw, 50vw" />
          </div>
          <div className="case__body">
            <p className="case__brand">{c.brand}</p>
            <h3 className="case__title">{c.title}</h3>
            <p className="case__summary">{c.summary}</p>
            <div className="case__metrics">
              {c.metrics.map((m) => (
                <div className="case__metric" key={m.label}><b>{m.value}</b><span>{m.label}</span></div>
              ))}
            </div>
            <div style={{ marginTop: "26px" }}>
              <button className="btn btn--ghost" onClick={() => openCase(c)}>More Info</button>
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}
