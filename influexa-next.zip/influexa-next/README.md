# Influexa — Production Website (Next.js)

Premium black-and-white gaming talent & campaign agency site. Same design as before, rebuilt as a modular, SEO-ready Next.js App Router app with a secure Resend email backend and clean URLs.

## Quick start
```bash
npm install
# create your env file (see Security below)
cp .env.local.example .env.local   # then paste your Resend key
npm run dev                        # http://localhost:3000
```
Build for production: `npm run build && npm start`.

## Clean URLs (no .html)
Routing is file-based, so URLs are already clean:
`/` · `/talent` · `/campaigns` · `/about` · `/connect`

## Folder structure
```
src/
├─ app/
│  ├─ layout.jsx          root: fonts, SEO metadata, JSON-LD, Nav/Footer
│  ├─ page.jsx            Home
│  ├─ talent/page.jsx     /talent
│  ├─ campaigns/page.jsx  /campaigns
│  ├─ about/page.jsx      /about  (founder featured + team)
│  ├─ connect/page.jsx    /connect (also opens as a modal anywhere)
│  ├─ api/contact/route.js   secure Resend endpoint (server only)
│  ├─ sitemap.js / robots.js
│  └─ globals.css         the design system (unchanged look)
├─ components/            reusable UI (Nav, Hero, grids, modals, form…)
├─ data/                  ← EDIT CONTENT HERE (see below)
└─ lib/                   sanitize + validate helpers
```

## Editing content — only touch `src/data/`
- `site.js` — company info, nav links, **footer links**, social links, form categories
- `campaigns.js` — every campaign + its pop-up detail (description, objectives, results, metrics, gallery)
- `brands.js` — Trusted-By brands (name, **logo path**, url)
- `talents.js` — featured influencers / roster (`featured: true` shows on home)
- `team.js` — founders & team (bio, **skills tags**, social links; `founder: true` = featured)
- `services.js` — service/strategy tiles + case studies

Add an item by copying one entry in the relevant array and changing the values. No layout code to touch.

### Brand logos (original colors)
`public/logos/` contains **colored placeholder** wordmarks. Replace each file with the brand's official logo (SVG or transparent PNG), keeping the same filename — or point `brands.js` at a new file. The section renders logos in full color (no monochrome filter).

### Images
Remote images (Unsplash) are optimized automatically via `next/image`. To use your own, drop files in `public/` and reference `/your-image.jpg`. Add any new remote image host to `images.remotePatterns` in `next.config.mjs`.

## Email backend (Resend) — security
- The API key lives **only** in `.env.local` (gitignored) and is read server-side in `src/app/api/contact/route.js`. It is **never** shipped to the browser.
- The form posts to `/api/contact`, which **validates**, **sanitizes** (strips control chars / header injection), and sends via Resend.
- Spam protection: hidden honeypot field, a timing trap, and a basic per-instance rate limit.
- Set a verified sender: in production, verify your domain in Resend and set `CONTACT_FROM="Influexa <hello@influexa.org>"`. The default `onboarding@resend.dev` only works for testing.

> ⚠️ **Rotate your key.** The key you shared was transmitted in plain text, so treat it as compromised: generate a new one in the Resend dashboard and put the new value in `.env.local`. Never commit that file.

## SEO & performance built in
- Per-page meta titles/descriptions, Open Graph, Twitter cards, canonical URLs (Next Metadata API)
- `Organization` + `WebSite` JSON-LD structured data (with founder)
- `sitemap.xml` and `robots.txt` auto-generated
- `next/image` (AVIF/WebP, lazy loading), automatic code splitting, font preconnect
- Add an OG image at `public/og.jpg` (1200×630) — referenced by metadata.

## Accessibility
Proper heading hierarchy, alt text on all images, keyboard-operable cards/menus (Enter/Space + Escape), visible focus rings, reduced-motion support.

## Notes on "copy protection"
Light, non-harmful measures only (disabled image dragging, security headers, hidden framework header). True client-side code can't be hidden from a browser, so nothing here blocks text selection, keyboard use, or crawlers — accessibility and SEO are untouched.
